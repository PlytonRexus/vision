"""Run smoke tests"""

import torchvision

print("torchvision version is ", torchvision.__version__)
